#!/bin/sh

# verbose
#export PS4='${LINENO}: '
#set -x

"$PRESSURE_VESSEL_RUNTIME_BASE/pressure-vessel/bin/steam-runtime-launch-client" \
    --pass-env-matching=STEAM* \
    --pass-env-matching=Steam* \
    --unset-env=WAYLAND_DISPLAY \
    --bus-name=com.steampowered.PressureVessel.LaunchAlongsideKiriARM \
    -- "$@"
