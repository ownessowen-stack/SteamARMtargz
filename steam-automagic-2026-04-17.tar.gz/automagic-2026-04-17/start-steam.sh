#!/usr/bin/env bash

# verbose
# export PS4='${LINENO}: '
set -x

set -o pipefail
shopt -s failglob
set -u

log () {
	echo "steam-init.sh[$$]: $*" >&2 || :
}
# This version interprets backslash escapes like echo -e
log_e () {
	echo -e "steam-init.sh[$$]: $*" >&2 || :
}

STEAMROOT="$(cd "$(dirname "$0")" && echo $PWD)"
if [ -z "${STEAMROOT}" ]; then
	log $"Couldn't find Steam root directory from "$0", aborting!"
	exit 1
fi

PLATFORM=steamrtarm64
RTARM64ROOT="$STEAMROOT/$PLATFORM"

if [ ! -x "$RTARM64ROOT" ]; then
	log "Downloading steam bootstrap"
	mkdir -p "$STEAMROOT/package"
	echo "publicbeta" > "$STEAMROOT/package/beta"
	wget -c -t 5 -O "$STEAMROOT/linuxarm64.zip" "https://client-update.steamstatic.com/bins_linuxarm64_linuxarm64.zip.f523fa87fc6b9b5435a5e7370cb0d664ef53b50b"
	unzip -d "$STEAMROOT" "$STEAMROOT/linuxarm64.zip" "steamrtarm64/steam"
	chmod +x "$RTARM64ROOT/steam"
fi

if [ ! -x "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt" ]; then
	log "Downloading steam-runtime"
	mkdir -p "$RTARM64ROOT/pv-runtime"
	wget -c -t 5 -O "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt-arm64.tar.xz" "https://repo.steampowered.com/steamrt3c/images/latest-public-beta/steam-runtime-steamrt-arm64.tar.xz"
	wget -c -t 5 -O "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt.sh" "https://repo.steampowered.com/steamrt3c/images/latest-public-beta/steam-runtime-steamrt-arm64.sh"
	tar -xvf "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt-arm64.tar.xz" --directory "$RTARM64ROOT/pv-runtime"
	mv "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt-arm64" "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt"
fi

mkdir -p "$HOME/.steam"
ln -s "$STEAMROOT/linuxarm64" "$HOME/.steam/sdkarm64"

if [ -x "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt" ]; then
    log "Starting steam-runtime"
    "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt/pressure-vessel/bin/steam-runtime-launcher-service" --bus-name com.steampowered.PressureVessel.LaunchAlongsideKiriARM --alongside-steam --verbose &
    "$RTARM64ROOT/pv-runtime/steam-runtime-steamrt/_v2-entry-point" -- "$STEAMROOT/steamrt-boot.sh" "$@"
else
    log "steam-runtime nor pressure-vessel are installed"
fi
