Steam for ARM (automagic)
-------------------------

1. copy `start-steam.sh` and `steamrt-boot.sh` into `~/.local/share/Steam`
2. run `start-steam.sh`
3. Steam for ARM will be downloaded automatically

~ KiriFops
